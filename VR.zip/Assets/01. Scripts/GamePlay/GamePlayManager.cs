using UnityEngine;

public class GamePlayManager : Singleton<GamePlayManager>
{
    public Transform correctPos;

    public int combo;
}
